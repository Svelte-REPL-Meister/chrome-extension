
// Svelte REPL Meister Chrome Extension
// Adds Auto-save, Global Search, Scroll position saving and Code History per Tab
// Injected in every https://svelte.dev/repl page:

// https://github.com/Svelte-REPL-Meister/chrome-extension

// LICENSE: unlicense.org

// VERSION HISTORY
// dec 23 2019 - v1.0 - initial release
// jan  3 2020 - v1.1 - fixed duplicate handlers/code search bug, added optional trace 

!(function addSvelteMeister() {

    const APPtitle = `Svelte REPL Meister v1.1`;

    // extra console logging information, toggle on/off with click on APPtitle
    let trace = false;//can not use: document.location.href.includes('trace');//Svelte resets/reloads URI

    // one name for id variables
    const constSRMerror = "SRMerror";
    const constSRMsearch = "SRMsearch";
    const constSRMcurrent = "SRMcurrent";
    const constrSRMaddhistory = "SRMaddHistory";
    const constrSRMhistorylist = "SRMHistoryList";
    const constSRMrestoreHistory = "SRMrestoreHistory";
    const constSRMdeleteHistory = "SRMdeleteHistory";
    const constSRMfirstload = "First load";
    const constSRMlastErrorTab = "lastErrorTab";

    // !! Svelte REPL deletes and creates new CodeMirror instance on each Tab switch
    // !! so we need to grab the correct DOM element every time
    const $CM = () => $class("CodeMirror").CodeMirror;

    let saveAllDelayInterval;
    let saveAllDelayTime = 1000 * 60;// after 60 seconds inactivity

    //!! Svelte REPL recreates CodeMIrror instance, so EventHandlers have to be re-attachecd, without creating duplicate handlers
    let CodeMirrorEventHandlers = [];

    log('initialized');

    function SRM_handleTabClick(evt) {
        // todo prevent doubleclick

        // !! the CodeMirror editor is destroyed/created by the Svelte REPL on each tab switch
        // !! this click function executes *after* those new DOM elements are created

        // experimental feature #5
        check_for_Svelte_Errors_report_to_console();

        $clicked_SvelteREPL_tabButton = SvelteREPL_findTabButton(evt.path);

        let tabid = $clicked_SvelteREPL_tabButton.id;

        if (!tabManager.has(tabid)) {
            tabManager.addTab(tabid)
            $clicked_SvelteREPL_tabButton.classList.add("SRMmanagedTab");
        } else {
            tabManager.selectTab(tabid);
        }

        tabManager.currentTab.saveEditorContent();

        showHistoryList();

        $store(constSRMcurrent, tabManager.currentTab.id);

        SvelteREPL_track_and_restore_ScrollPosition();
        SvelteREPL_saveAllFiles();
        SvelteREPL_CodeMirror_EventHandlers();
    }


    /** classes ************************************************************************************************************
     * 
     * SRMTabManager
     * - _previousTab
     * - _currentTab
     * - tabs #Map() 
     * - tabi
     * - has(id)
     * - addTab(id)
     * - selectTab(id)
     * - get tabEntries()
     * - get previousTab()
     * - get currentTab()
     * - saveHistory()
     *    SRMTab
     *    - tabid
     *    - value
     *    - histories #SRMHistories()
     *    - saveEditorContent(changeObj)
     *    - saveHistory(label)
     *    - deleteHistory(historyid)
     *    - get Historyentries()
     *       SRMHistories
     *       - tabid
     *       - save([historid])
     *          SRMTabHistory
     *          - tabid
     *          - historyid
     *          - value
     *          - update(content)
     *          - restore()
     *          - remove()
     * 
     */
    class SRMTabHistory {
        constructor(tabid, historyid) {
            this.tabid = tabid;
            this.historyid = historyid;
            if (trace) log(`new History (${tabid}) ${historyid}`);
            this.value = $CM().doc.getValue();
        }
        update(content) {
            this.value = content;
        }
        restore() {
            //            tabManager.tabs.get(this.tabid).saveHistory();
            $CM().doc.setValue(this.value);
        }
        remove() {
            tabManager.tabs.get(this.tabid).deleteHistory(this.historyid);
        }
    }
    class SRMHistories extends Map {
        constructor(tabid) {
            super();
            this.tabid = tabid;
        }
        save(historyid = new Date() / 1) {
            this.set(historyid, new SRMTabHistory(this.tabid, historyid));
        }
    }
    class SRMTab {
        constructor(tabid) {
            this.tabid = tabid;
            this.value = "";
            this.histories = new SRMHistories(tabid);
            this._LINE = 0;          // line number
            this._CH = 0;            // character number in line

            this.saveHistory(constSRMfirstload);
        }
        saveEditorContent(changeObj) {// CodeMirror changeObj
            this.value = $CM().doc.getValue();
            if (changeObj) {
                this._LINE = changeObj.from.line + 1;
                this._CH = changeObj.from.ch;
            }
            if (trace) log("saveEditor", this.tabid, this.value.length, 'bytes', 'line:', this._LINE, this, changeObj ? 'By CodeMirror Event' : '');
        }
        saveHistory(label) {
            this.histories.save(label);
        }
        deleteHistory(historyid) {
            this.histories.delete(historyid);
        }
        get Historyentries() {
            return [...this.histories.entries()];
        }
    }
    class SRMTabManager {
        constructor() {
            this._previousTab = false;
            this._currentTab = false;
            this.tabs = new Map();
        }
        has(id) {
            return this.tabs.has(id);
        }
        addTab(id) {
            this.tabs.set(id, new SRMTab(id));
            return this.selectTab(id);
        }
        selectTab(id) {
            this._previousTab = this._currentTab;
            this._currentTab = id;
            let _tab = this.tabs.get(id)
            if (trace) log(id, _tab);
            return _tab;
        }
        get tabEntries() {
            return this.tabs.entries();
        }
        get previousTab() {
            return this.tabs.get(this._previousTab);
        }
        get currentTab() {
            return this.tabs.get(this._currentTab);
        }
        saveHistory() {
            this.currentTab.saveHistory();
            //showHistoryList();
        }
    }

    //!! Init
    const tabManager = new SRMTabManager();              // store all Tab data

    let $clicked_SvelteREPL_tabButton = $id("App");  // initial/first Svelte REPL tab // todo get tab from localStorage

    window.stabs = tabManager;// for debugging purposes

    add_SRM_GUI_Interface();

    add_SRM_SearchBoxListener();

    $class("file-tabs").addEventListener("click", SRM_handleTabClick); // one click event for all Svelte Tabs

    $clicked_SvelteREPL_tabButton.click();// click first tab 


    /** hoisted functions ************************************************************************************************************
     * $(selector)
     * $class(classname)
     * $id(id)
     * addEvent(...)
     * throttled(delay,func)
     * log(...arguments)
     * add_SRM_GUI_Interface()
     * add_SRM_SearchBoxListener()
     * SvelteREPL_findTabButton(evtpath)
     * SvelteREPL_saveAllFiles()
     * SvelteREPL_track_and_restore_ScrollPosition()
     * SvelteREPL_CodeMirror_EventHandlers()
     * showHistoryList()
     * date2time(timestamp)
     * addHistoryItemHTML(entry)
     * check_for_Svelte_Errors_report_to_console()
     */

    function $(x) {
        return document.querySelector(x);
    }
    function $class(x) {
        return $("." + x);
    }
    function $id(x) {
        return $("#" + x);
    }
    function $store(x, y = false) {
        return localStorage[(y ? "set" : "get") + "Item"](x, y);
    }

    function addEvent({
        element = document,
        eventtype = "click",
        selector = console.error("addEvent: missing selector"),
        func = console.error("addEvent: missing function declaration")
    }) {
        element
            .querySelector(selector)
            .addEventListener(eventtype, throttled(1000, func));
    }

    function throttled(delay, fn) {
        let lastCall = 0;
        return function (...args) {
            const now = (new Date).getTime();
            if (now - lastCall < delay) return;
            lastCall = now;
            return fn(...args);
        }
    }

    function log() {
        // using console.info because console.log is overwritten in (my) other extensions
        console.info(`%c ${APPtitle}: `, "background:#FF3E00;color:white", ...arguments); // svelte --prime color background
    }

    /**
     * Main Svelte REPL Meister UI
     */
    function add_SRM_GUI_Interface() {
        // injected HTML
        let HTMLsearch = `<span>search: <input id=${constSRMsearch} type=text placeholder="seen/green tabs!"/>  </span>`;
        let HTMLerror = `<span id=${constSRMerror} style="color:orange;"></span>`;
        let HTMLheader = `<div id=SRMheader><span id="apptitle">${APPtitle}</span> - ${HTMLsearch} - ${HTMLerror}<span class=${constSRMcurrent}></span>&nbsp;&nbsp;</div>`;

        if (!$id("SRMheader"))
            $class("app-controls").insertAdjacentHTML("afterbegin", HTMLheader);

        document
            .getElementById('apptitle')
            .addEventListener("click", () => {
                trace = !trace;
                log('trace', trace ? 'ON' : 'OFF', tabManager);
            });
    }

    /**
     * add searchbox listener, output search results to the F12 console
     */
    function add_SRM_SearchBoxListener() {
        let searchInput = $id(constSRMsearch);
        if (searchInput) searchInput.addEventListener("keyup", SRM_processSearch);//end search code

        function SRM_processSearch(evt) {
            if (evt.key === "Enter") {
                let txt = evt.target.value;
                log(`Searched: ${txt} `);

                const foundTextLine = (str, i) => str.includes(txt) && [i + 1, str] || false;            // record found and linenr
                const validLines = x => x && x[1].length < 120;                                          // disregard very long lines in (encoded) files
                const txtmatches = str => str.match(new RegExp(txt, "g"));
                const countOccurences = (str, matches = txtmatches(str)) => matches ? matches.length : 0;
                const highlightedSentence = str => str.trim().split(txt).join(`%c${txt}%c`);
                const logSearchResult = x => console.info(x, "background:lightgreen", "background:white");// multiple occurences are not highlighted

                for (let [tabid, tab] of tabManager.tabEntries) {

                    const consoleSentence = ([linenr, str]) => countOccurences(str) + ` found in: ${tabid} \t line: ${linenr} \t` + highlightedSentence(str);
                    const showLineInConsole = x => logSearchResult(consoleSentence(x));

                    tab.value// process one tab editor contents (from memory)
                        .split("\n")
                        // lines become array items: [ linenr , text ]
                        .map(foundTextLine)
                        .filter(validLines)
                        .forEach(showLineInConsole);
                }
            }
        }
    }// addSearchBoxListener

    /**
     * Find the correct SvelteTab from the Tab click event (attached to the parent DIV)
     * @param {*} evtpath 
     */
    function SvelteREPL_findTabButton(evtpath) {
        const isButton = x => evtpath[x].classList.contains("button");
        const isDocument = x => evtpath[x] === document;
        const notButtonTab = x => !isButton(x) && !isDocument(x);

        let idx = 0;
        while (notButtonTab(idx)) idx++;
        return evtpath[idx];
    }

    function SvelteREPL_saveAllFiles() {
        $('button[title="save"').click();
    }

    function SvelteREPL_track_and_restore_ScrollPosition() {
        const saveTabScollPosition = evt => tabManager.currentTab.scrollTop = $class("CodeMirror-scroll").scrollTop;

        $class("CodeMirror-scroll").addEventListener("scroll", saveTabScollPosition);
        $class("CodeMirror-scroll").scrollTop = tabManager.currentTab.scrollTop; // restore scoll position
    }

    /**
     * add Event Handlers to the active CodeMirror instance
    */
    function SvelteREPL_CodeMirror_EventHandlers() {
        CodeMirrorEventHandlers.map(removehandler => removehandler());// remove all added CodeMiror Handlers

        const addCodeMirrorEvent = (name, func) => {
            $CM().on(name, func);                   // attach CodeMirror handler
            return () => $CM().off(name, func);     // return CodeMirror off handler FUNCTION to remove Handler
        }

        //log('add CodeMirror CHANGE event', tabManager.currentTab.tabid);
        let remove_change = addCodeMirrorEvent("change", function (doc, changeObj) {

            if (changeObj.origin === "setValue") {
                //!! race condition when switching Tabs: CodeMirror created by Svelte is the NEW tab!
                //!! but currentTab is still the previous tab
                //!! can NOT do:
                //!! tabManager.currentTab.saveEditorContent(changeObj);
            } else if (changeObj.origin === "+input") {                 // new content added in tab
                tabManager.currentTab.saveEditorContent(changeObj);
            } else {
                log("CodeMirror change event:", changeObj.origin, tabManager.currentTab.tabid, changeObj);
            }

            // experimental feature #5 detecting error locations
            setTimeout(() => {
                if ($(".message.error")) {
                    $store(constSRMlastErrorTab, `${tabManager.currentTab.id}:${tabManager.currentTab._LINE}`);
                    console.error($store(constSRMlastErrorTab));
                }
            });

            clearInterval(saveAllDelayInterval);
            saveAllDelayInterval = setInterval(SvelteREPL_saveAllFiles, saveAllDelayTime);
        });

        CodeMirrorEventHandlers.push(remove_change);

        //!!do more here... remember to not add eventhandler multiple times
        // addCodeMirrorEvent("keyHandled", function (cm, keyname, evt) {
        //log("", keyname);
        // });
        // addCodeMirrorEvent("blur", function (CM, evt) {
        //log("blur");
        // });

    }

    /**
     * display the HistoryList for the current Tab
     */
    function showHistoryList() {

        let $history = $id(constrSRMhistorylist);
        if ($history) {
            // clean existing Tab History List
            $history.innerHTML = "";
        } else {
            // create new Tab History List
            let $List = $class("CodeMirror").appendChild(document.createElement("DIV"));
            $List.id = "SRMHistory";// used by CSS
            $List.innerHTML = `<b id="${constrSRMaddhistory}">History +</b><div id="${constrSRMhistorylist}"></div>`;
            addEvent({
                selector: "#" + constrSRMaddhistory,
                func: evt => {
                    tabManager.saveHistory();
                    showHistoryList();
                }
            });
        }

        // add History List Items
        (tabManager.currentTab.Historyentries).forEach(addHistoryItemHTML);
    }

    /**
     * convert timestamp to HH:MM:SS notation
     * @param {*} timestamp 
     */
    function date2time(timestamp) {
        if (typeof timestamp === "string") return timestamp;

        const D = new Date(timestamp);
        const pad = x => String(x).padStart(2, "0");

        return pad(D.getHours()) + ":" + pad(D.getMinutes()) + ":" + pad(D.getSeconds());
    }

    /**
     * Add HistoryList DOM entry for new current tab content
     * @param {*} entry 
     */
    function addHistoryItemHTML(entry) {
        let [historyid, SRMHistoryItem] = entry;

        const historyIsSameAsEditor = tabManager.currentTab.value === SRMHistoryItem.value;

        const SPAN = (className, content) => `<span class="${className}">${content}</span>`;
        const HTMLrestoreLabel = SPAN(constSRMrestoreHistory, date2time(historyid));
        const HTMLdeleteLabelX = SPAN(constSRMdeleteHistory, "X")

        const restoreHistory = evt => {
            SRMHistoryItem.restore();
            showHistoryList();
        }
        const removeHistory = evt => {
            $button.remove();
            SRMHistoryItem.remove($button)
            showHistoryList();
        };

        const addClick = (selector, func) => addEvent({ element: $button, selector, func });

        //create DOM element in HistoryList
        let $button = document.createElement("DIV");

        $button.setAttribute("tabid", SRMHistoryItem.tabid);
        $button.setAttribute("historyid", historyid);
        $button.classList.toggle("SRMequalValue", historyIsSameAsEditor);
        $button.innerHTML = HTMLrestoreLabel + HTMLdeleteLabelX;

        $id(constrSRMhistorylist).prepend($button);  // latest at the top

        addClick("." + constSRMrestoreHistory, restoreHistory);
        addClick("." + constSRMdeleteHistory, removeHistory);
    }

    //feature #5 , try some better error reporting
    function check_for_Svelte_Errors_report_to_console() {
        if (tabManager.currentTab) {
            if ($(".message.error")) {
                let lastError = $store(constSRMerror);
                if (lastError) {
                    console.error("%c Last Svelte Error in: ", "background:red;color:white", lastError);
                } else {
                    $store(constSRMerror, tabManager.currentTab.id);
                }
                $id(constSRMerror).innerHTML = "last error in: " + $store(constSRMerror);
            } else {
                $id(constSRMerror).innerHTML = "";
                localStorage.removeItem(constSRMerror);
            }
        }
    }

})();